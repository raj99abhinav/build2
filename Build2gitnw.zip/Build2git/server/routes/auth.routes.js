import express from 'express'
// import nodemailer from 'nodemailer'
// import nodemSmtpTransport from 'nodemailer-smtp-transport'

import authCtrl from '../controllers/auth.controller'

const router = express.Router()

router.route('/auth/signin')
  .post(authCtrl.signin)
router.route('/auth/signout')
  .get(authCtrl.signout)

router.get('/verify', function (req, res) {
  console.log(req.protocol + ":/" + req.get('host'));
  if (req.query.id == 1) {
    //console.log("Email " + mailOptions.to + " is been Successfully verified");
  }
  else {
    console.log("Bad Request");
  }
});

export default router